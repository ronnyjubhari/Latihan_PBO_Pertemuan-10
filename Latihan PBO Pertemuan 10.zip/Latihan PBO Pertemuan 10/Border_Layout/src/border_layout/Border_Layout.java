/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package border_layout;

import java.awt.BorderLayout;
import java.awt.Frame;
import javax.swing.*;
/**
 *
 * @author RECKY
 */
public class Border_Layout extends JFrame{

    /**
     * @param args the command line arguments
     */
    JButton nButton = new JButton("North");
    JButton sButton = new JButton("South");
    JButton eButton = new JButton("East");
    JButton wButton = new JButton("West");
    JButton cButton = new JButton("Center");
    
    public Border_Layout() {
        super("Border Layout Beraksi");
        setSize(240, 280);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
            add(nButton, BorderLayout.NORTH);
            add(sButton, BorderLayout.SOUTH);
            add(eButton, BorderLayout.EAST);
            add(wButton, BorderLayout.WEST);
            add(cButton, BorderLayout.CENTER);
    }
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        Border_Layout frame = new Border_Layout();
        frame.setVisible(true);
    }
    
}
